ace.require(["ace/snippets/scrypt"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
