ace.require(["ace/snippets/assembly_x86"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
