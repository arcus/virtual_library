ace.require(["ace/snippets/sparql"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
