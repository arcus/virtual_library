ace.require(["ace/snippets/prql"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
