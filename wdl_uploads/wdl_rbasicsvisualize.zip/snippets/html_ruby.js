ace.require(["ace/snippets/html_ruby"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
