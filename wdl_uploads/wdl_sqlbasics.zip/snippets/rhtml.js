ace.require(["ace/snippets/rhtml"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
