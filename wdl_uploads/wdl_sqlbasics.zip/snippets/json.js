ace.require(["ace/snippets/json"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
