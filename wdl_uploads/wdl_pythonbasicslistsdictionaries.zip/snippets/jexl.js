ace.require(["ace/snippets/jexl"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
