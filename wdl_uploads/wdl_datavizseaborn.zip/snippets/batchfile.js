ace.require(["ace/snippets/batchfile"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
