ace.require(["ace/snippets/zeek"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
